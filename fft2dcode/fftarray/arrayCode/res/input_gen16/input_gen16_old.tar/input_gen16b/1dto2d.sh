#!/usr/bin/bash
COUNTER=0
while [  $COUNTER -lt 64 ]; do
     echo The counter is $COUNTER
     let COUNTER=COUNTER+1 
    `less ip_data.list >> ip_data_1dto2d.list`
    `less ip_data_readable.list >> ip_data_readable_1dto2d.list`
done
