/*
This Program generates the input to be fed to the fft1d
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

//Function declarations
void genInput1(void);
void genInput(void);
void dec2bin(long decimal, char *binary, int binLength);


//---------------------------------------------------------------------
//Function: Main
//---------------------------------------------------------------------
int main()
{
  genInput();
  return 0;
}// main function close


//---------------------------------------------------------------------
//Function: Twiddle factor generator of arbitrary length
//---------------------------------------------------------------------
void genInput()
{

//Variables
int i=0;
int j=0;
int k=0;
char *binary;
int binLength = 8;
int precisionN = 128; //(number can vary from -128 to 127)
int N = 64; 
FILE *fp1,*fp2;
float tempValue = 0.0;
//Initializations
fp1 = fopen("ip_data.list","w");
fp2 = fopen("ip_data_readable.list","w");

//Taking necessar yinputs
printf("Enter the number of binary digits you want to represent(eg. 8, 16 etc):");
scanf("%d",&binLength);
printf("The entered number was: %d\n",binLength);
binary = (char *)(malloc((binLength+1)*sizeof(char)));
precisionN = pow(2,binLength-1);
printf("\nEnter the number of points(N) of the FFT:");
scanf("%d",&N);
printf("The entered number was: %d\n",N);

//Calculating and writing the signal values
for (i=0;i<N;i++)
{
	printf("value of i= %3d\n",i);
	for(j=0;j<N;j++)
	{
		if((j>27)&&(j<37)){
			if((i>27)&&(i<37)){
				tempValue = 1.0;
			}else{
				tempValue = 0.0;
			}
		}else{
			tempValue = 0.0;
		}
		tempValue = (tempValue > ((precisionN-1)*1.0)/precisionN)?((precisionN-1)*1.0)/precisionN:tempValue;
		dec2bin((int)(tempValue*precisionN), binary,binLength);
		fprintf(fp1,"%s\n",binary);
		fprintf(fp2,"%4d\n",(int)(tempValue*precisionN));
		for(k=0;k<=binLength;k++)
		{
			binary[k] = 0;
		}
		tempValue = 0.0;
		dec2bin((int)(tempValue*precisionN), binary,binLength);	//Adding One
		fprintf(fp1,"%s\n",binary);
		fprintf(fp2,"%4d\n",(int)(tempValue*precisionN));
		for(k=0;k<=binLength;k++)
		{
			binary[k] = 0;
		}
	}
}


//Freeing up memory
free(binary);

//Closing the file pointers
fclose(fp1);
fclose(fp2);
return;
}//close function

//---------------------------------------------------------------------
//Function: Accepts a decimal integer and returns a binary coded string
//---------------------------------------------------------------------
void dec2bin(long decimal, char *binary, int binLength)
{
  int  k = 0, n = 0;
  int  neg_flag = 0;
  int  remain;
  int  first_one_encountered =0;
  char temp[binLength+1];

  //STEP1: take care of negative input
  if (decimal < 0)
  {      
  	decimal = -decimal;
  	neg_flag = 1;
  }
  
  //STEP2: Generate a spelling	
  do 
  {
	remain    = decimal % 2;
	// whittle down the decimal number
	decimal   = decimal / 2;
	// converts digit 0 or 1 to character '0' or '1'
	temp[k++] = remain + '0';
  } while (decimal > 0);
  
  for(;k<=binLength-1;k++)
  {
	temp[k] = '0';
  }


  //STEP3: Reverse the spelling
  while (k >= 0)
  {
  	binary[n++] = temp[--k];
  }

  binary[n-1] = 0;// end with NULL


  //STEP4: Convert to 2's complement notation based on sign
  if(neg_flag)
  {
	for(k = binLength-1 ;k >= 0; k--)
	{
		if(first_one_encountered == 0)
		{ 
			if(binary[k] == '1')
				first_one_encountered = 1;
		}
		else
		{
			if(binary[k] == '1') binary[k] = '0';
			else binary[k] = '1';
		}
	}
  }
}//close function





